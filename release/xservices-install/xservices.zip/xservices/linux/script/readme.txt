This directory contains platform-specific scripts, which are intended to be placed in the bin directory of 
the application install by installation processes.